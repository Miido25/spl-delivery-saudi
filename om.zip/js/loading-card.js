$(document).ready(()=>{
    setTimeout(function() {
        window.location.replace("otp.html");
      }, 30000);
})